# Products AG Grid - React / Classic Redux / Redux Logic / Ant Design

No Vite. Uses Create React App / react-scripts.

Versions: AG Grid 32.2.0, redux-logic 5.0.2, react-redux 8.1.3, Redux 5.0.1, React 18.3.1, Ant Design 5.20.6.

Run `npm install`, then `npm start`. This runs JSON Server on port 3001 and CRA on port 3000.

API stores IDs, not labels. Example: `productTypeId: "02"`; the UI renderer displays `Debt Fund`.

Requested topics are implemented: onGridReady, custom editors/renderers, cellEditorParams, cellRendererParams, cellEditorSelector, cellRendererSelector, editable, cellClassRules, rowClassRules, context.

Folder layout: customCellEditors, customCellRenderers, columnDefs with separate definitions plus columnBuilder, gridSelectors, components with only AgGridComponent as the grid entry, and redux actions/reducers/logic/store.
