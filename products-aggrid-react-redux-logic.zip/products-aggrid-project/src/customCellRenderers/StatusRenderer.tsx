import React from'react';import{Tag}from'antd';export default function StatusRenderer({value}:{value:boolean}){return <Tag color={value?'green':'red'}>{value?'Active':'Inactive'}</Tag>}
