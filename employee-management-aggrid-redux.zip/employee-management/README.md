# Employee Management Dashboard

React + TypeScript + Classic Redux + Redux-Logic + Ant Design + AG Grid.

## Exact core versions

- AG Grid Community: 32.2.0
- AG Grid React: 32.2.0
- Redux Logic: 5.0.2
- React Redux: 8.1.3
- Redux: 5.0.1
- React: 18.3.1
- Ant Design: 5.20.6
- React Scripts: 5.0.1

## No Vite

This project uses Create React App / react-scripts.

## Install

```bash
npm install
```

## Start

```bash
npm start
```

## Build

```bash
npm run build
```

## AG Grid concepts included

1. onGridReady
2. Custom Cell Editors
3. Custom Cell Renderers
4. cellEditorParams
5. cellRendererParams
6. cellEditorSelector
7. cellRendererSelector
8. editable
9. cellClassRules
10. rowClassRules
11. context

## Architecture

React
 -> Redux dispatch
 -> Redux-Logic
 -> Mock API
 -> Redux action
 -> Reducer
 -> React / AG Grid

## Important learning points

- This intentionally uses classic Redux rather than Redux Toolkit.
- Redux-Logic handles asynchronous CRUD operations.
- `context` contains the current user's grid permissions.
- `editable` uses those permissions.
- `cellEditorSelector` changes the editor configuration based on row data.
- `cellRendererSelector` changes renderer configuration based on row data.
- `cellClassRules` styles individual cells.
- `rowClassRules` styles entire rows.
- `onGridReady` captures the Grid API.
