export type EmployeeType = "Full Time" | "Part Time" | "Contractor";
export type EmployeeStatus = "Active" | "Inactive" | "On Leave";

export interface Employee {
  id: number;
  name: string;
  email: string;
  department: string;
  employeeType: EmployeeType;
  role: string;
  salary: number;
  performance: number;
  status: EmployeeStatus;
  joiningDate: string;
}

export interface GridUserContext {
  userRole: "ADMIN" | "MANAGER" | "VIEWER";
  canEdit: boolean;
  canDelete: boolean;
}