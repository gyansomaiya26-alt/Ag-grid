import React from "react";
import { Layout, Typography } from "antd";
import EmployeeGrid from "./components/EmployeeGrid/EmployeeGrid";

const { Header, Content } = Layout;

const App: React.FC = () => {
  return (
    <Layout className="app-layout">
      <Header className="app-header">
        <Typography.Title level={3} style={{ color: "#fff", margin: 0 }}>
          Employee Management Dashboard
        </Typography.Title>
      </Header>

      <Content className="app-content">
        <EmployeeGrid />
      </Content>
    </Layout>
  );
};

export default App;