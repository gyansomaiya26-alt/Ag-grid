import { Employee } from "../types/employee";

export const employees: Employee[] = [
  {
    id: 1001,
    name: "Rahul Sharma",
    email: "rahul@company.com",
    department: "Engineering",
    employeeType: "Full Time",
    role: "Frontend Developer",
    salary: 85000,
    performance: 92,
    status: "Active",
    joiningDate: "2023-04-12"
  },
  {
    id: 1002,
    name: "Priya Mehta",
    email: "priya@company.com",
    department: "HR",
    employeeType: "Full Time",
    role: "HR Manager",
    salary: 72000,
    performance: 86,
    status: "Active",
    joiningDate: "2022-08-19"
  },
  {
    id: 1003,
    name: "Aman Verma",
    email: "aman@company.com",
    department: "Engineering",
    employeeType: "Contractor",
    role: "Backend Developer",
    salary: 95000,
    performance: 48,
    status: "Active",
    joiningDate: "2024-01-10"
  },
  {
    id: 1004,
    name: "Neha Gupta",
    email: "neha@company.com",
    department: "Finance",
    employeeType: "Part Time",
    role: "Accountant",
    salary: 45000,
    performance: 68,
    status: "On Leave",
    joiningDate: "2023-11-03"
  },
  {
    id: 1005,
    name: "Arjun Singh",
    email: "arjun@company.com",
    department: "Marketing",
    employeeType: "Full Time",
    role: "Marketing Manager",
    salary: 78000,
    performance: 38,
    status: "Inactive",
    joiningDate: "2021-06-15"
  }
];