import { employees as initialEmployees } from "../data/employees";
import { Employee } from "../types/employee";

let database = [...initialEmployees];

export const fetchEmployees = (): Promise<Employee[]> =>
  new Promise((resolve) => {
    setTimeout(() => resolve([...database]), 600);
  });

export const updateEmployee = (employee: Employee): Promise<Employee> =>
  new Promise((resolve) => {
    setTimeout(() => {
      database = database.map((item) =>
        item.id === employee.id ? employee : item
      );
      resolve(employee);
    }, 400);
  });

export const deleteEmployee = (employeeId: number): Promise<number> =>
  new Promise((resolve) => {
    setTimeout(() => {
      database = database.filter((item) => item.id !== employeeId);
      resolve(employeeId);
    }, 400);
  });

export const addEmployee = (employee: Employee): Promise<Employee> =>
  new Promise((resolve) => {
    setTimeout(() => {
      database = [...database, employee];
      resolve(employee);
    }, 400);
  });