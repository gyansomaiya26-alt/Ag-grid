import { RootState } from "../reducers/rootReducer";

export const selectEmployees = (state: RootState) =>
  state.employees.employees;

export const selectEmployeeLoading = (state: RootState) =>
  state.employees.loading;

export const selectEmployeeError = (state: RootState) =>
  state.employees.error;