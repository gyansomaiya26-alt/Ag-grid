import { applyMiddleware, createStore } from "redux";
import { createLogicMiddleware } from "redux-logic";
import rootReducer from "./reducers/rootReducer";
import logic from "./logic/employeeLogic";

const logicMiddleware = createLogicMiddleware();

const store = createStore(
  rootReducer,
  applyMiddleware(logicMiddleware)
);

logicMiddleware.addLogic(logic);

export default store;