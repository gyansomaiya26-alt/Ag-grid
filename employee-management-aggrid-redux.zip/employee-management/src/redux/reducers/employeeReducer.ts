import { AnyAction } from "redux";
import { Employee } from "../../types/employee";

interface EmployeeState {
  employees: Employee[];
  loading: boolean;
  error: string | null;
}

const initialState: EmployeeState = {
  employees: [],
  loading: false,
  error: null
};

const employeeReducer = (
  state = initialState,
  action: AnyAction
): EmployeeState => {
  switch (action.type) {
    case "FETCH_EMPLOYEES":
      return { ...state, loading: true, error: null };

    case "FETCH_EMPLOYEES_SUCCESS":
      return {
        ...state,
        loading: false,
        employees: action.payload
      };

    case "FETCH_EMPLOYEES_FAILURE":
      return {
        ...state,
        loading: false,
        error: action.payload
      };

    case "UPDATE_EMPLOYEE_SUCCESS":
      return {
        ...state,
        employees: state.employees.map((employee) =>
          employee.id === action.payload.id ? action.payload : employee
        )
      };

    case "DELETE_EMPLOYEE_SUCCESS":
      return {
        ...state,
        employees: state.employees.filter(
          (employee) => employee.id !== action.payload
        )
      };

    case "ADD_EMPLOYEE_SUCCESS":
      return {
        ...state,
        employees: [...state.employees, action.payload]
      };

    default:
      return state;
  }
};

export default employeeReducer;