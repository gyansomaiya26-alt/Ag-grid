import { combineReducers } from "redux";
import employeeReducer from "./employeeReducer";

const rootReducer = combineReducers({
  employees: employeeReducer
});

export type RootState = ReturnType<typeof rootReducer>;

export default rootReducer;