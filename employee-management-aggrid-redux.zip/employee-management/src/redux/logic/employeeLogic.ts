import { createLogic } from "redux-logic";
import {
  FETCH_EMPLOYEES,
  fetchEmployeesSuccess,
  fetchEmployeesFailure,
  UPDATE_EMPLOYEE,
  updateEmployeeSuccess,
  DELETE_EMPLOYEE,
  deleteEmployeeSuccess,
  ADD_EMPLOYEE,
  addEmployeeSuccess
} from "../actions/employeeActions";
import {
  fetchEmployees,
  updateEmployee,
  deleteEmployee,
  addEmployee
} from "../../api/employeeApi";

export const fetchEmployeesLogic = createLogic({
  type: FETCH_EMPLOYEES,
  latest: true,
  process({ dispatch }: any) {
    return fetchEmployees()
      .then((data) => dispatch(fetchEmployeesSuccess(data)))
      .catch((error) =>
        dispatch(fetchEmployeesFailure(error?.message || "Unable to load employees"))
      );
  }
});

export const updateEmployeeLogic = createLogic({
  type: UPDATE_EMPLOYEE,
  process({ action, dispatch }: any) {
    return updateEmployee(action.payload).then((employee) =>
      dispatch(updateEmployeeSuccess(employee))
    );
  }
});

export const deleteEmployeeLogic = createLogic({
  type: DELETE_EMPLOYEE,
  process({ action, dispatch }: any) {
    return deleteEmployee(action.payload).then((employeeId) =>
      dispatch(deleteEmployeeSuccess(employeeId))
    );
  }
});

export const addEmployeeLogic = createLogic({
  type: ADD_EMPLOYEE,
  process({ action, dispatch }: any) {
    return addEmployee(action.payload).then((employee) =>
      dispatch(addEmployeeSuccess(employee))
    );
  }
});

export default [
  fetchEmployeesLogic,
  updateEmployeeLogic,
  deleteEmployeeLogic,
  addEmployeeLogic
];