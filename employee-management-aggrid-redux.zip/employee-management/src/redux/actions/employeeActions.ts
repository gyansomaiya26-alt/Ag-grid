import { Employee } from "../../types/employee";

export const FETCH_EMPLOYEES = "FETCH_EMPLOYEES";
export const FETCH_EMPLOYEES_SUCCESS = "FETCH_EMPLOYEES_SUCCESS";
export const FETCH_EMPLOYEES_FAILURE = "FETCH_EMPLOYEES_FAILURE";

export const UPDATE_EMPLOYEE = "UPDATE_EMPLOYEE";
export const UPDATE_EMPLOYEE_SUCCESS = "UPDATE_EMPLOYEE_SUCCESS";

export const DELETE_EMPLOYEE = "DELETE_EMPLOYEE";
export const DELETE_EMPLOYEE_SUCCESS = "DELETE_EMPLOYEE_SUCCESS";

export const ADD_EMPLOYEE = "ADD_EMPLOYEE";
export const ADD_EMPLOYEE_SUCCESS = "ADD_EMPLOYEE_SUCCESS";

export const fetchEmployees = () => ({ type: FETCH_EMPLOYEES });

export const fetchEmployeesSuccess = (employees: Employee[]) => ({
  type: FETCH_EMPLOYEES_SUCCESS,
  payload: employees
});

export const fetchEmployeesFailure = (error: string) => ({
  type: FETCH_EMPLOYEES_FAILURE,
  payload: error
});

export const updateEmployee = (employee: Employee) => ({
  type: UPDATE_EMPLOYEE,
  payload: employee
});

export const updateEmployeeSuccess = (employee: Employee) => ({
  type: UPDATE_EMPLOYEE_SUCCESS,
  payload: employee
});

export const deleteEmployee = (employeeId: number) => ({
  type: DELETE_EMPLOYEE,
  payload: employeeId
});

export const deleteEmployeeSuccess = (employeeId: number) => ({
  type: DELETE_EMPLOYEE_SUCCESS,
  payload: employeeId
});

export const addEmployee = (employee: Employee) => ({
  type: ADD_EMPLOYEE,
  payload: employee
});

export const addEmployeeSuccess = (employee: Employee) => ({
  type: ADD_EMPLOYEE_SUCCESS,
  payload: employee
});