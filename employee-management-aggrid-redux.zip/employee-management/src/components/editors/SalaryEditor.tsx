import React, { useState } from "react";

interface Props {
  value: number;
  onValueChange: (value: number) => void;
}

const SalaryEditor: React.FC<Props> = ({ value, onValueChange }) => {
  const [salary, setSalary] = useState<number>(value ?? 0);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const nextValue = Number(event.target.value);
    setSalary(nextValue);
    onValueChange(nextValue);
  };

  return (
    <input
      autoFocus
      className="editor-input"
      type="number"
      value={salary}
      onChange={handleChange}
    />
  );
};

export default SalaryEditor;