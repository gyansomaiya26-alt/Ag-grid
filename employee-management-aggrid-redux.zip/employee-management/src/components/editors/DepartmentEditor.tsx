import React, { useState } from "react";
import { Select } from "antd";

interface Props {
  value: string;
  values?: string[];
  onValueChange: (value: string) => void;
}

const DepartmentEditor: React.FC<Props> = ({
  value,
  values = [],
  onValueChange
}) => {
  const [department, setDepartment] = useState(value);

  return (
    <Select
      autoFocus
      open
      value={department}
      style={{ width: "100%" }}
      options={values.map((item) => ({ label: item, value: item }))}
      onChange={(nextValue) => {
        setDepartment(nextValue);
        onValueChange(nextValue);
      }}
    />
  );
};

export default DepartmentEditor;