import React, { useState } from "react";
import { Select } from "antd";

interface Props {
  value: string;
  values?: string[];
  onValueChange: (value: string) => void;
}

const EmployeeTypeEditor: React.FC<Props> = ({
  value,
  values = [],
  onValueChange
}) => {
  const [employeeType, setEmployeeType] = useState(value);

  return (
    <Select
      autoFocus
      open
      value={employeeType}
      style={{ width: "100%" }}
      options={values.map((item) => ({ label: item, value: item }))}
      onChange={(nextValue) => {
        setEmployeeType(nextValue);
        onValueChange(nextValue);
      }}
    />
  );
};

export default EmployeeTypeEditor;