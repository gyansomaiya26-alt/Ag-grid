import React from "react";
import { ColDef, ICellRendererParams, ICellEditorParams } from "ag-grid-community";
import EmployeeRenderer from "../renderers/EmployeeRenderer";
import StatusRenderer from "../renderers/StatusRenderer";
import PerformanceRenderer from "../renderers/PerformanceRenderer";
import ActionRenderer from "../renderers/ActionRenderer";
import SalaryEditor from "../editors/SalaryEditor";
import DepartmentEditor from "../editors/DepartmentEditor";
import EmployeeTypeEditor from "../editors/EmployeeTypeEditor";
import { Employee, GridUserContext } from "../../types/employee";

const departments = ["Engineering", "HR", "Finance", "Marketing", "Sales"];
const employeeTypes = ["Full Time", "Part Time", "Contractor"];

export const getEmployeeColumns = (
  context: GridUserContext,
  onDelete: (id: number) => void
): ColDef<Employee>[] => [
  {
    field: "id",
    headerName: "ID",
    width: 90,
    editable: false
  },
  {
    field: "name",
    headerName: "Employee",
    minWidth: 240,
    flex: 1,
    editable: context.canEdit,
    cellRendererSelector: (params: ICellRendererParams<Employee>) => ({
      component: EmployeeRenderer,
      params: {
        email: params.data?.email
      }
    } as any),
    cellRendererParams: (params: ICellRendererParams<Employee>) => ({
      email: params.data?.email
    })
  },
  {
    field: "department",
    headerName: "Department",
    editable: context.canEdit,
    cellEditorSelector: (params: ICellEditorParams<Employee>) => ({
      component: DepartmentEditor,
      params: {
        values: params.data?.employeeType === "Contractor"
          ? ["Engineering", "Sales", "Marketing"]
          : departments
      }
    } as any),
    cellEditorParams: (params: ICellEditorParams<Employee>) => ({
      values: params.data?.employeeType === "Contractor"
        ? ["Engineering", "Sales", "Marketing"]
        : departments
    })
  },
  {
    field: "employeeType",
    headerName: "Employee Type",
    editable: context.canEdit,
    cellEditorSelector: (params: ICellEditorParams<Employee>) => {
      if (params.data?.department === "Engineering") {
        return {
          component: EmployeeTypeEditor,
          params: { values: ["Full Time", "Contractor"] }
        } as any;
      }

      return {
        component: EmployeeTypeEditor,
        params: { values: employeeTypes }
      } as any;
    },
    cellEditorParams: {
      values: employeeTypes
    }
  },
  {
    field: "role",
    headerName: "Role",
    editable: context.canEdit
  },
  {
    field: "salary",
    headerName: "Salary",
    editable: context.canEdit,
    valueFormatter: (params) =>
      `₹${Number(params.value).toLocaleString("en-IN")}`,
    cellEditor: SalaryEditor,
    cellEditorParams: (params: ICellEditorParams<Employee>) => ({
      min: params.data?.employeeType === "Contractor" ? 30000 : 40000
    }),
    cellClassRules: {
      "performance-good": (params) => Number(params.value) >= 80000,
      "performance-warning": (params) => Number(params.value) < 50000
    }
  },
  {
    field: "performance",
    headerName: "Performance",
    editable: context.canEdit,
    cellRenderer: PerformanceRenderer,
    cellRendererParams: {
      showPercent: true
    },
    cellClassRules: {
      "performance-good": (params) => Number(params.value) >= 80,
      "performance-warning": (params) =>
        Number(params.value) >= 50 && Number(params.value) < 80,
      "performance-poor": (params) => Number(params.value) < 50
    }
  },
  {
    field: "status",
    headerName: "Status",
    editable: context.canEdit,
    cellRendererSelector: (params: ICellRendererParams<Employee>) => {
      if (params.value === "Inactive") {
        return {
          component: StatusRenderer,
          params: { highlight: true }
        } as any;
      }

      return {
        component: StatusRenderer,
        params: { highlight: false }
      } as any;
    },
    cellRendererParams: {
      highlight: false
    }
  },
  {
    field: "joiningDate",
    headerName: "Joining Date",
    editable: false
  },
  {
    headerName: "Actions",
    width: 120,
    editable: false,
    cellRendererSelector: (params: ICellRendererParams<Employee>) => ({
      component: ActionRenderer,
      params: {
        onDelete
      }
    } as any)
  }
];