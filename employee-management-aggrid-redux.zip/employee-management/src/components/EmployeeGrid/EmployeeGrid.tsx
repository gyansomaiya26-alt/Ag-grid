import React, { useCallback, useEffect, useMemo, useRef } from "react";
import { Alert, Button, Card, Space, Spin, Typography, message } from "antd";
import { ReloadOutlined } from "@ant-design/icons";
import { AgGridReact } from "ag-grid-react";
import {
  CellValueChangedEvent,
  GridApi,
  GridReadyEvent
} from "ag-grid-community";
import { useDispatch, useSelector } from "react-redux";

import {
  deleteEmployee,
  fetchEmployees,
  updateEmployee
} from "../../redux/actions/employeeActions";
import {
  selectEmployeeError,
  selectEmployeeLoading,
  selectEmployees
} from "../../redux/selectors/employeeSelectors";
import { RootState } from "../../redux/reducers/rootReducer";
import { Employee, GridUserContext } from "../../types/employee";
import { getEmployeeColumns } from "./employeeColumns";

const EmployeeGrid: React.FC = () => {
  const dispatch = useDispatch();
  const gridApiRef = useRef<GridApi<Employee> | null>(null);

  const employees = useSelector((state: RootState) =>
    selectEmployees(state)
  );
  const loading = useSelector((state: RootState) =>
    selectEmployeeLoading(state)
  );
  const error = useSelector((state: RootState) =>
    selectEmployeeError(state)
  );

  const gridContext: GridUserContext = useMemo(
    () => ({
      userRole: "ADMIN",
      canEdit: true,
      canDelete: true
    }),
    []
  );

  useEffect(() => {
    dispatch(fetchEmployees());
  }, [dispatch]);

  const onGridReady = useCallback(
    (params: GridReadyEvent<Employee>) => {
      gridApiRef.current = params.api;
      params.api.sizeColumnsToFit();
    },
    []
  );

  const handleDelete = useCallback(
    (id: number) => {
      if (!gridContext.canDelete) return;
      dispatch(deleteEmployee(id));
      message.success(`Employee ${id} deleted`);
    },
    [dispatch, gridContext]
  );

  const handleCellValueChanged = useCallback(
    (event: CellValueChangedEvent<Employee>) => {
      if (!event.data || event.oldValue === event.newValue) return;
      dispatch(updateEmployee(event.data));
      message.success(`${event.colDef.headerName} updated`);
    },
    [dispatch]
  );

  const columnDefs = useMemo(
    () => getEmployeeColumns(gridContext, handleDelete),
    [gridContext, handleDelete]
  );

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      filter: true,
      resizable: true
    }),
    []
  );

  return (
    <Card className="employee-card">
      <div className="grid-toolbar">
        <Typography.Title level={4} style={{ margin: 0 }}>
          Employees
        </Typography.Title>

        <Space>
          <Button
            icon={<ReloadOutlined />}
            onClick={() => dispatch(fetchEmployees())}
          >
            Reload
          </Button>
        </Space>
      </div>

      {error && <Alert type="error" message={error} />}

      <Spin spinning={loading}>
        <div className="ag-theme-alpine">
          <AgGridReact<Employee>
            rowData={employees}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            context={gridContext}
            onGridReady={onGridReady}
            onCellValueChanged={handleCellValueChanged}
            singleClickEdit={true}
            stopEditingWhenCellsLoseFocus={true}
            rowClassRules={{
              "employee-row-inactive": (params) =>
                params.data?.status === "Inactive",
              "employee-row-warning": (params) =>
                (params.data?.performance ?? 100) < 50
            }}
            animateRows={true}
          />
        </div>
      </Spin>
    </Card>
  );
};

export default EmployeeGrid;