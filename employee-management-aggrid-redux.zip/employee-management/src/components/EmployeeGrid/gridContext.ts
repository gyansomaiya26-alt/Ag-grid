import { GridUserContext } from "../../types/employee";

export const gridContext: GridUserContext = {
  userRole: "ADMIN",
  canEdit: true,
  canDelete: true
};