import React from "react";
import { Button, Space } from "antd";
import { DeleteOutlined } from "@ant-design/icons";

interface Props {
  data: { id: number };
  onDelete?: (id: number) => void;
}

const ActionRenderer: React.FC<Props> = ({ data, onDelete }) => (
  <Space>
    <Button
      danger
      size="small"
      icon={<DeleteOutlined />}
      onClick={() => onDelete?.(data.id)}
    >
      Delete
    </Button>
  </Space>
);

export default ActionRenderer;