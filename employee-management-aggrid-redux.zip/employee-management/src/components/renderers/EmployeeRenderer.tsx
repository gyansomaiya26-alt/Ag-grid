import React from "react";
import { Avatar, Space, Typography } from "antd";

interface Props {
  value: string;
  email?: string;
}

const EmployeeRenderer: React.FC<Props> = ({ value, email }) => (
  <Space>
    <Avatar>{value?.charAt(0)}</Avatar>
    <span>
      <Typography.Text strong>{value}</Typography.Text>
      <br />
      <Typography.Text type="secondary" style={{ fontSize: 11 }}>
        {email}
      </Typography.Text>
    </span>
  </Space>
);

export default EmployeeRenderer;