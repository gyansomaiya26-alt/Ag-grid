import React from "react";
import { Progress } from "antd";

const PerformanceRenderer: React.FC<{ value: number }> = ({ value }) => (
  <Progress
    percent={value}
    size="small"
    status={value < 50 ? "exception" : value < 70 ? "normal" : "success"}
  />
);

export default PerformanceRenderer;