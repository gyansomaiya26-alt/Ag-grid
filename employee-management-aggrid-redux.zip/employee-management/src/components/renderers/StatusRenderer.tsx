import React from "react";
import { Tag } from "antd";

const StatusRenderer: React.FC<{ value: string }> = ({ value }) => {
  const color =
    value === "Active" ? "green" :
    value === "Inactive" ? "red" : "orange";

  return <Tag color={color}>{value}</Tag>;
};

export default StatusRenderer;