# AG Grid feature map

| Requested topic | File | Example |
|---|---|---|
| onGridReady | `src/components/EmployeeGrid/EmployeeGrid.tsx` | Stores Grid API and calls `sizeColumnsToFit()` |
| Custom CellEditors | `src/components/editors/*.tsx` | Salary, Department, Employee Type |
| Custom cellRenderers | `src/components/renderers/*.tsx` | Employee, Status, Performance, Actions |
| CellEditorParams | `employeeColumns.tsx` | Dynamic editor values |
| CellRendererParams | `employeeColumns.tsx` | Email, callbacks, renderer config |
| CellEditorSelector | `employeeColumns.tsx` | Employee Type / Department editor selection |
| CellRendererSelector | `employeeColumns.tsx` | Status / Employee / Action renderer selection |
| Editable | `employeeColumns.tsx` | Permission-based editing |
| CellClassRules | `employeeColumns.tsx` | Salary and performance styling |
| RowClassRules | `EmployeeGrid.tsx` | Inactive / low-performance rows |
| Context | `EmployeeGrid.tsx` | `userRole`, `canEdit`, `canDelete` |
